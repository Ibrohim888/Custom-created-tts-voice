---
name: Tactical HUD Interface
colors:
  surface: '#0e1320'
  surface-dim: '#0e1320'
  surface-bright: '#343948'
  surface-container-lowest: '#090e1b'
  surface-container-low: '#161b29'
  surface-container: '#1a1f2d'
  surface-container-high: '#252a38'
  surface-container-highest: '#303443'
  on-surface: '#dee2f5'
  on-surface-variant: '#bbc9ce'
  inverse-surface: '#dee2f5'
  inverse-on-surface: '#2b303e'
  outline: '#859398'
  outline-variant: '#3c494d'
  surface-tint: '#00d9ff'
  primary: '#afecff'
  on-primary: '#003641'
  primary-container: '#00d9ff'
  on-primary-container: '#005b6c'
  inverse-primary: '#00687b'
  secondary: '#aac7ff'
  on-secondary: '#003064'
  secondary-container: '#3e90ff'
  on-secondary-container: '#002957'
  tertiary: '#b3ebff'
  on-tertiary: '#003642'
  tertiary-container: '#4cd6fb'
  on-tertiary-container: '#005a6e'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#aeecff'
  primary-fixed-dim: '#00d9ff'
  on-primary-fixed: '#001f26'
  on-primary-fixed-variant: '#004e5d'
  secondary-fixed: '#d6e3ff'
  secondary-fixed-dim: '#aac7ff'
  on-secondary-fixed: '#001b3e'
  on-secondary-fixed-variant: '#00468d'
  tertiary-fixed: '#b3ebff'
  tertiary-fixed-dim: '#4cd6fb'
  on-tertiary-fixed: '#001f27'
  on-tertiary-fixed-variant: '#004e5f'
  background: '#0e1320'
  on-background: '#dee2f5'
  surface-variant: '#303443'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: 0.05em
  display-md:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: 0.04em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: 0.03em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 30px
    letterSpacing: 0.02em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: 0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  label-lg:
    fontFamily: Space Mono
    fontSize: 13px
    fontWeight: '700'
    lineHeight: 18px
    letterSpacing: 0.08em
  label-md:
    fontFamily: Space Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.1em
  label-sm:
    fontFamily: Space Mono
    fontSize: 9px
    fontWeight: '400'
    lineHeight: 12px
    letterSpacing: 0.12em
  code-telemetry:
    fontFamily: Space Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.05em
spacing:
  gutter: 1rem
  margin: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system embodies the high-performance, holographic intelligence of a next-generation desktop AI assistant. Designed for situational dominance, high-density data synthesis, and effortless multi-threaded control, the visual language merges tactical military-grade avionics with bleeding-edge holographic compute infrastructure. 

Targeted at power operators, technical pioneers, and system commanders, the interface evokes focus, absolute situational awareness, precision, and technological omnipotence. The design style combines:
- **Sci-Fi Tactical Glassmorphism:** Semi-transparent, ultra-deep dark glass panels with micro-refraction and luminous cyan boundary lines.
- **HUD Micro-Detailing:** Functional framing geometry, corner brackets, optical tick marks, reticle crosshairs, and live telemetry channels.
- **Luminous Holography:** Layered lighting where critical data emanates energy via additive photonic glows against deep void canvases.

## Colors

The color system operates on an additive optical model designed for high-contrast visibility against abyssal backgrounds:

- **Primary (`#00D9FF` - Hyper Cyan):** The primary active state and energetic signature. Used for key telemetry outputs, active states, circular gauge conduits, and high-priority AI feedback.
- **Secondary (`#0A84FF` - Electric Blue):** Structural accents, secondary logic paths, stable operational nodes, and deep holographic shadows.
- **Tertiary (`#00B4D8` - Plasma Cerulean):** Intermediate data indicators, soundwave frequency bars, and supportive telemetry tracks.
- **Neutral Surface (`#080D1A` - Deep Void Navy) & Canvas (`#050811` - Abyssal Black):** The absorbing background structure that prevents optical wash and lets neon signals punch through with distinct legibility.
- **Accent High-White (`#E6FCFF` with cyan bloom):** Vectors, pinpoint crosshairs, target acquisition markers, and peak readings.
- **Semantic Overrides:** Critical alerts drop to incandescent amber (`#FF9500`) or tactical breach red (`#FF2A42`), but remain framed in cyan-bracketed containment.

## Typography

The typographic hierarchy establishes clear data tiering using three complementary typefaces:

- **Display & Headlines (`Space Grotesk`):** Delivers aerodynamic, technical geometry with controlled character shapes. All headlines adopt slight tracking expansion to simulate telemetry and avionics readouts.
- **Body (`Inter`):** Selected for high-density legibility in assistant dialogue transcripts, diagnostic logs, and multi-line AI responses. Inter provides neutral clarity without visual fatigue.
- **Labels, Telemetry & Status Codes (`Space Mono`):** Fixed-pitch monospaced precision. Capitalization is strictly uppercase for `label-md` and `label-sm` tiers to preserve the tactical military avionics character. Numeric metrics rely on tabular figures to prevent jitter during real-time telemetry streaming.

## Layout & Spacing

The layout is grounded in a persistent command-deck paradigm using a 12-column dynamic modular grid:

- **Canvas Distribution:** Centered around a central core focus zone (dedicated to speech visualization, 3D diagnostics, or arc-reactor state rings), framed by modular situational rail panels to the left and right.
- **Margins & Gutters:** Rigid `1.5rem` boundaries ensure high-speed visual anchoring without clipping outer crosshair elements. Inner gutter channels stay locked to `1rem` to enforce tight instrumental cohesion.
- **Micro-Grid:** Internal component layout operates on a strict 4px/8px rhythm. All diagnostic metrics, status tags, and audio spectrum strips align strictly along the primary axis.
- **Breakpoints:**
  - **Desktop Core (>= 1440px):** Full 12-column view with simultaneous left/right operational rails and persistent arc telemetry.
  - **Compact Desktop / Landscape Tablet (1024px - 1439px):** Rails fold into collapsible HUD side-drawers; primary interaction matrix takes 8 columns.
  - **Mobile / Tactical Remote (< 1024px):** Single-column stacked telemetry stack with sliding modal sheets and compact micro-gauges.

## Elevation & Depth

Visual hierarchy uses photonic depth and translucent material layering rather than traditional drop shadows:

- **Surface 0 (Void Ground):** Solid `#050811` augmented with a faint, low-opacity (2%) polar coordinate grid and static HUD horizon lines.
- **Surface 1 (HUD Deck Panels):** `#080D1A` at 65% opacity combined with `backdrop-filter: blur(16px)` and a 1px border rendered in `rgba(0, 217, 255, 0.15)`.
- **Surface 2 (Active Sub-Nodes & Hover Modules):** `#0A1428` at 75% opacity, `backdrop-filter: blur(24px)`, bounded by `rgba(0, 217, 255, 0.4)` with 4px corner tick brackets.
- **Surface 3 (Alerts & Focal Overlays):** `#081026` at 90% opacity, bordered with solid `#00D9FF` and elevated via dual exterior optical blooms: `0 0 15px rgba(0, 217, 255, 0.35)` and `0 0 45px rgba(10, 132, 255, 0.15)`.
- **Photonic Vectors:** Non-interactive decorative graphics use additive glow blending (`mix-blend-mode: screen`), creating radiant light overlap when elements intersect.

## Shapes

The HUD geometry uses strict, angular lines. Fillets and soft radiuses are avoided to maintain an authentic military avionics look.

- **Primary Geometry:** 0px border radius across all primary structural cards, modals, and telemetry frames.
- **Chamfered Offsets (Tactile Angle Cut):** Major interactive containers and primary action triggers use a 45-degree chamfered cut (`clip-path: polygon(...)`) on either the top-right, bottom-left, or opposing diagonal corners (cut depth: 8px to 12px).
- **Corner Brackets & Reticles:** Panel edges feature disconnected L-shaped framing vectors (crosshairs) positioned at the outer boundary limits, reinforcing the targeting-glass illusion.
- **Concentric Circular Nodes:** Arc-reactor meters, central frequency spinners, and radar nodes use pure concentric rings and segmented radial segments.

## Components

### Buttons & Tactical Triggers
- **Primary:** Angular chamfered shape with semi-transparent cyan fill (`rgba(0, 217, 255, 0.12)`), solid 1px `#00D9FF` border, and high-contrast uppercase `Space Mono` text. Hover activates an immediate cyan flood (`#00D9FF`) with deep `#050811` inverted text and an outer `0 0 20px rgba(0, 217, 255, 0.6)` corona.
- **Secondary / Ghost:** Pure 1px `rgba(10, 132, 255, 0.4)` border with corner bracket accents. Text in `#00B4D8`.
- **Interactive State Feedback:** Instantaneous activation without sluggish spring animations; uses swift, clinical 100ms optical transitions.

### Cards & HUD Panels
- Translucent backdrop with persistent 1px wireframe outline.
- Each card incorporates micro-details: a top-left diagnostic label (`SYS_REF // 094`), miniature calibration tick marks along the right border, and dynamic L-bracket crosshairs on opposite vertices.

### Circular Arc-Reactor Gauges
- Multi-layered SVGs with rotating segmented tracks, numerical readouts centered in `Space Grotesk`, and pulsating cyan inner rings.
- Secondary telemetry data (voltages, processing load, audio sync) scales dynamically across outer tick marks.

### Soundwave & Frequency Visualizers
- Vertical bar arrays using variable opacity neon bars (`#00D9FF` fading to `#0A84FF`).
- Real-time oscillation responsive to voice input/output, bordered by minimal decibel calibration axes and high-frequency peak markers.

### Input Fields & Terminal Prompts
- Background in `rgba(8, 13, 26, 0.8)` with a bottom-heavy cyan border line (1px top/sides, 2px glowing bottom).
- Prefixed with terminal chevrons (`>`) and a blinking block or line cursor in bright `#00D9FF`.

### Status Tags & Diagnostics Chips
- Compact, sharp-edged rectangular badges with an integrated pulsing LED indicator (3px circle or diamond).
- Color-coded: Nominal (Cyan), Standby (Electric Blue), Compromised (Amber/Red), with semi-transparent background tints and uppercase monospaced labels.

### Checkboxes & Segmented Controls
- Binary switches represented as angled slide toggles or hollow squares that fill with an illuminated cyan inner reticle when active.