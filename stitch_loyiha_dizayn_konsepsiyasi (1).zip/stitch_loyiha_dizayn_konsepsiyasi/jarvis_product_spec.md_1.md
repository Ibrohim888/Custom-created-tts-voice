# JARVIS AI AGENT — MAHSULOT SPETSIFIKATSIYASI

## 1. Umumiy g'oya

Iron Man filmidagi Jarvisga o'xshash shaxsiy AI yordamchi. Windows kompyuterda `.exe` fayl orqali ishga tushadigan native dastur. Kompyuterni to'liq boshqaradi, ekranni ko'radi, ovoz orqali gaplashadi, filmga o'xshash vizual interfeys bilan, Telegram orqali masofadan ham boshqariladi.

**Maqsadli kompyuter (muhim cheklov):** Intel G630 (2 yadro, 2.7-2.8GHz), GT210 GPU (512MB VRAM). Bu **zaif, eski konfiguratsiya** — barcha og'ir hisoblash (LLM, STT, TTS, vision) **bulutli API'lar orqali** bajarilishi shart. Kompyuterda faqat yengil klient ishlaydi (audio yozish, skrinshot olish, GUI render, tool bajarish).

---

## 2. Vizual interfeys (GUI)

### 2.1 Kichik widget (doimiy holat)
- Ekranning bir chetida doim ko'rinib turadi (masalan pastki o'ng burchak)
- Kichik, shaffof, minimalistik — Jarvis holatini ko'rsatadi (tinglayapti/o'ylayapti/gapiryapti/uyquda)
- Doim ustida (always-on-top), boshqa dasturlarga xalaqit bermaydi

### 2.2 To'liq HUD ekran (faollashganda)
- Wake word ("Hey Jarvis") aytilganda to'liq ekranga yoyiladigan overlay ochiladi
- **Iron Man HUD uslubi**: shaffof fon, ko'k/moviy neon ranglar, aylanma elementlar, animatsiyalar
- Ovozli to'lqin animatsiyasi (Jarvis gapirayotganda/tinglayotganda vizual feedback)
- Qilinayotgan amaliyot ko'rsatiladi (masalan: "Brauzer ochilmoqda...", "Fayl qidirilmoqda...")
- Vazifa tugagach yoki bir muddat harakatsizlikdan keyin avtomatik kichik widget holatiga qaytadi

### 2.3 Rang sxemasi
- Asosiy: ko'k/moviy (klassik Iron Man HUD rangi — masalan #00D9FF, #0A84FF)
- Fon: qora/shaffof
- Urg'u ranglar: oq chiziqlar, nozik glow effektlar

### 2.4 Dizayn ishlab chiqarish jarayoni
- GUI dizayni **Google Stitch** (stitch.withgoogle.com) orqali yaratiladi: matn prompt orqali HUD ekrani va widget mockup'i generatsiya qilinadi, so'ng HTML/CSS (yoki React) kodi eksport qilinadi
- Stitch'dan chiqqan kod **asos** sifatida ishlatiladi; kodlash agenti buning ustiga JavaScript orqali jonli animatsiya (pulsatsiya, ovoz to'lqini, holat almashinuvi: tinglayapti/o'ylayapti/gapiryapti/uyquda) qo'shadi
- Talab: ekran ko'rinishi va funksionalligi **kinodagi Jarvis HUD'ga imkon qadar yaqin** bo'lishi shart — statik chiroyli dizayn yetarli emas, holat o'zgarishlariga jonli reaksiya bo'lishi kerak

---

## 3. Ovoz tizimi

### 3.1 Faollashtirish
- **Wake word**: "Hey Jarvis" (yoki shunga o'xshash) — doim fonda tinglab turadi, faqat shu so'z aytilganda to'liq faollashadi
- Wake word aniqlash **lokal** ishlashi kerak (internetga bog'liq bo'lmasdan, tez javob uchun) — masalan Porcupine yoki OpenWakeWord kabi yengil kutubxona

### 3.2 STT (ovozdan matnga)
- Wake word'dan keyingi nutq **bulutli API** orqali matnga aylantiriladi (masalan Groq Whisper — tez va bepul)

### 3.3 TTS (matndan ovozga)
- **Bulutli, bepul yechim** — kompyuterda og'ir model ishlatilmaydi
- Ingliz/rus tili: Edge-TTS (masalan `en-GB-RyanNeural` — britaniyacha erkak ovoz, Jarvis hissini beradi; sozlangan pitch/rate bilan)
- O'zbek tili: Aisha TTS API (agar ochiq/barqaror API mavjud bo'lsa) yoki muqobil yechim
- Til avtomatik aniqlanadi, mos TTS xizmatiga yo'naltiriladi

---

## 4. "Miya" (LLM) va fikrlash

### 4.1 Model routing
- **Tez/oddiy vazifalar**: Llama 3.3 70B (Groq API, bepul, tez)
- **Chuqur fikrlash talab qiladigan vazifalar** (murakkab reja, kod, ko'p bosqichli masala): DeepSeek R1 (bepul variant)
- Avtomatik tanlov: so'rov murakkabligiga qarab tizim o'zi qaysi modelni ishlatishni hal qiladi

### 4.2 Tool calling
LLM quyidagi "tool"larni chaqira oladi:
- Fayl tizimi (ochish, yaratish, o'chirish, ko'chirish)
- Dastur ishga tushirish/yopish
- Brauzer boshqarish
- Terminal buyruqlari
- Ekran skrinshoti va vizual tahlil
- Mouse/klaviatura boshqarish

---

## 5. Kompyuterni boshqarish (Computer Use)

### 5.1 Umumiy vazifalar (barchasi bir xil muhim)
- Fayl va papkalar bilan ishlash
- Dastur/ilovalarni ochish, yopish, boshqarish
- Brauzerda harakat qilish (qidirish, sahifalarni ochish, formalarni to'ldirish)
- Terminal/kodlash muhitida ishlash
- Multimedia boshqaruvi (musiqa, video)

### 5.2 O'yin o'ynash (eksperimental, alohida bosqich)
- Perceive-think-act tsikli orqali (skrinshot → LLM tahlili → harakat → takror)
- Sekin/navbat asosidagi o'yinlarda (shaxmat, strategiya) yaxshi ishlaydi
- Tezkor o'yinlarda (shooter) sekin ishlaydi — bu arxitekturaning tabiiy chegarasi, kutilishi kerak

### 5.3 Xavfsizlik
- **Xavfli amallar uchun tasdiq so'raladi**: fayl o'chirish, dastur o'rnatish/o'chirish, tizim sozlamalarini o'zgartirish va shunga o'xshash qaytarib bo'lmaydigan yoki katta ta'sirli amallar
- Oddiy, xavfsiz amallar (fayl ochish, qidiruv, dastur ishga tushirish) tasdiqsiz bajariladi

---

## 6. Xotira tizimi

### 6.1 Nimalar eslab qolinadi
- **Suhbat tarixi**: foydalanuvchi bilan bo'lgan barcha gaplashuvlar
- **Faoliyat jurnali**: qaysi dasturlar ochilgani, qanday vazifalar bajarilgani, qachon
- **Foydalanuvchi haqida kontekst**: shaxsiy tafsilotlar, tercihlar, odatlar, davom etayotgan loyihalar (vaqt o'tishi bilan to'planadi)

### 6.2 Qanday ishlaydi
- Persistent xotira (SQLite + vektor qidiruv) — har bir yangi so'rovda tegishli eski ma'lumotlar qidirilib, LLM promptiga qo'shiladi
- Vaqt o'tishi bilan Jarvis foydalanuvchini "tanib boradi" — takroriy tushuntirishlar kerak bo'lmaydi

---

## 7. Telegram Bridge (masofaviy boshqaruv)

- Matn orqali yozib gaplashish
- Ovozli xabar yuborish va qabul qilish (STT/TTS orqali qayta ishlanadi)
- Kompyuterdagi Jarvis bilan bir xil "miya" va xotiraga ulanadi — masofadan bergan buyruq ham xuddi shu tarzda bajariladi

---

## 8. Tizim xatti-harakati

- Windows bilan birga **avtomatik ishga tushadi** (startup'ga qo'shiladi)
- Fonda kichik widget sifatida ishlaydi, resurslarni minimal sarflaydi (kuchsiz kompyuter uchun muhim)
- Internet yo'qolsa: asosiy funksiyalar (LLM, STT, TTS) ishlamay qoladi, chunki ular bulutga bog'liq — bu haqda widget orqali foydalanuvchiga bildiriladi

---

## 9. Ishlab chiqish bosqichlari (roadmap)

1. **MVP**: Ovoz kirish-chiqish (wake word + STT + LLM + TTS), oddiy widget UI
2. **HUD ekran**: To'liq ekran overlay, Iron Man uslubidagi vizual dizayn va animatsiyalar
3. **Ekran vision**: Skrinshot olib, LLM'ga tahlil qildirish
4. **Computer use**: Fayl, dastur, brauzer, terminal boshqaruvi (xavfsizlik tasdig'i bilan)
5. **Model routing**: Llama/DeepSeek orasida avtomatik tanlov
6. **Xotira tizimi**: Suhbat + faoliyat tarixi + foydalanuvchi konteksti
7. **Telegram bridge**: Matn va ovoz orqali masofaviy boshqaruv
8. **Game agent**: Perceive-think-act tsikli orqali o'yin o'ynash (eksperimental)
9. **Startup integratsiyasi**: Windows bilan avtomatik ishga tushish, `.exe` packaging

---

## 10. Texnik cheklovlar (agent har doim yodda tutishi kerak)

- Kompyuter **zaif** (2 yadro CPU, 512MB VRAM GPU) — hech qanday og'ir lokal AI model (voice cloning, lokal LLM, lokal vision model) ishlatilmasin
- Barcha AI hisoblash **bulutli, bepul API'lar** orqali bo'lishi shart (Groq, Edge-TTS, va h.k.)
- Wake word aniqlash lokal bo'lishi mumkin (yengil, past resurs talab qiladi)
